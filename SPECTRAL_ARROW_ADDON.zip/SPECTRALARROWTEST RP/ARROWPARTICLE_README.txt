arrow particle needs:

randomized directions

go up rather than down

maybe faster animation using "minecraft:particle_lifetime_expression"

use snowstorm website to make a new particle to make life easier :)